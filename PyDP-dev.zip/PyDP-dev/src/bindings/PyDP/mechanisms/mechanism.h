// supposed to extend classes of numerical mechanism class and add on top of it
// a good idea would be to keep the numerical mechanism as base class in case we add
// completely new noise mechanism