# stdlib
import sys

# pydp absolute
from pydp import algorithms
from pydp import distributions
from pydp import util
from pydp import ml

__version__ = "1.1.1"
