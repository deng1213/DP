# Introduction to Laplace Distribution

This example walksthrough why it is required to add noise to make data private. It motivates for the use of Laplace distribution's to make it easy to satisfy ε-differential privacy by setting the b parameter to 1/ε.