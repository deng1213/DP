# Codelab

Please check out [Privacy on Beam codelab](https://codelabs.developers.google.com/codelabs/privacy-on-beam/)
for instructions.

See [main/main.go](main/main.go) for instructions on how to run the codelab
binary in Windows or in Linux with Bazel or with the "go" command.
